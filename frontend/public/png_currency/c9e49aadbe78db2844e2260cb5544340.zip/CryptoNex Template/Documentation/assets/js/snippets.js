const htmlStructure = `
<!DOCTYPE html>
<html lang="en">
    <head>
        [Meta Tag, Title, Favicon, CSS etc...]
  </head>
  <body>
    <!-- Start Preloader -->
    <div class="preloader">
        [Preloader]
    </div>
    <!-- End Preloader -->

    <!-- Start Header -->
    <header>
        [Navigation Bar]
    </header>
    <!-- End Header -->

    <!-- Scroll To Top -->
    <i class="fa fa-arrow-up" id="scroll-top"></i>

    <!-- Start Hero -->
    <section class="hero" id="hero">
        [Hero Section Content]
    </section>
    <!-- End Hero -->

    <!-- Start About -->
    <section class="about" id="about">
        [About Section Content]
    </section>
    <!-- End About -->

    <!-- Start Market -->
    <section class="market" id="market">
        [Market Section Content]
    </section>
    <!-- End Market -->

    <!-- Start Features -->
    <section class="features" id="features">
        [Features Section Content]
    </section>
    <!-- End Features -->

    <!-- Start Process -->
    <section class="process" id="process">
        [Process Section Content]
    </section>
    <!-- End Process -->

    <!-- Start App -->
    <section class="app" id="app">
        [App Section Content]
    </section>
    <!-- End App -->

    <!-- Start Testimonial -->
    <section class="testimonial">
        [Testimonial Section Content]
    </section>
    <!-- End Testimonial -->

    <!-- Start Blog -->
    <section class="blog" id="blog">
        [Blog Section Content]
    </section>
    <!-- End Blog -->

    <!-- Start FAQ -->
    <section class="faq" id="faq">
        [FAQ Section Content]
    </section>
    <!-- End FAQ -->

    <!-- Start Contact -->
    <section class="contact" id="contact">
        [Contact Section Content]
    </section>
    <!-- End Contact -->

    <!-- Start Footer -->
    <footer>
        [Footer]
    </footer>
    <!-- End Footer -->

    [Javascript Files]
  </body>
</html>
`;

const cssFiles = `<!-- Css Files -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/css/fontawesome.min.css" />
<link rel="stylesheet" href="assets/css/magnific-popup.min.css" />
<link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />
<link rel="stylesheet" href="assets/css/aos.css" />
<link rel="stylesheet" href="assets/css/main.css" />`;

const jsFiles = `<!-- Javascript Files -->
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/apexcharts.min.js"></script>
<script src="assets/js/charts.js"></script>
<script src="assets/js/aos.js"></script>
<script src="assets/js/main.js"></script>`;

const favicon = `<!-- Favicon -->
<link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon" />`;

const logo = `<a class="navbar-brand" href="#">
    <img src="assets/img/logo.png" alt="Logo" class="logo" />
</a>`;

const preloader = `<!-- Start Preloader -->
<div class="preloader">
    <div class="loader-ripple">
        <div></div>
        <div></div>
    </div>
</div>
<!-- End Preloader -->`;

const googleFonts = `/* Importing Google Fonts */
@import url("https://fonts.googleapis.com/css2?family=Cabin:wght@300;400;500;600;700;800&display=swap");

/* Using Google Fonts */
* {
    font-family: "Cabin", sans-serif;
}`;

const fontawesome = `<!-- Linking Fontawesome -->
<link rel="stylesheet" href="assets/css/fontawesome.min.css" />
 
<!-- Using Fontawesome Icons -->
<i class="fab fa-facebook-f"></i>`;

const sliderOptions = `$(".partner-slider").owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    dots: false,
    autoplay: true,
    responsiveClass: true,
    responsive: {
        0: { items: 1 },
        576: { items: 2 },
        768: { items: 3 },
        1200: { items: 4 },
    },
});`;

const addYoutubeVideo = `<a href="https://www.youtube.com/watch?v=Mvrq8hLjcRk" class="play-button">
    <img src="assets/img/play.svg" alt="Play" />
    <span>How It Works</span>
</a>`;

const addVimeoVideo = `<a href="https://vimeo.com/347119375" class="play-button">
    <img src="assets/img/play.svg" alt="Play" />
    <span>How It Works</span>
</a>`;

const manageSections = `<ul class="navbar-nav ms-auto mb-2 mb-lg-0">
    <li class="nav-item">
        <a class="nav-link" aria-current="page" href="#hero">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#about">About</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#market">Market</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#features">Features</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#blog">Blog</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#faq">FAQ</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#contact">Contact</a>
    </li>
    <li class="nav-item ms-2">
        <a class="button-secondary" href="#">Connect Wallet </a>
    </li>
</ul>`;

$("#html-structure pre code").html(Prism.highlight(htmlStructure, Prism.languages.html, "html"));
$("#css-files pre code").html(Prism.highlight(cssFiles, Prism.languages.html, "html"));
$("#js-files pre code").html(Prism.highlight(jsFiles, Prism.languages.html, "html"));
$("#favicon pre code").html(Prism.highlight(favicon, Prism.languages.html, "html"));
$("#logo pre code").html(Prism.highlight(logo, Prism.languages.html, "html"));
$("#preloader pre code").html(Prism.highlight(preloader, Prism.languages.html, "html"));
$("#google-fonts pre code").html(Prism.highlight(googleFonts, Prism.languages.html, "html"));
$("#fontawesome pre code").html(Prism.highlight(fontawesome, Prism.languages.html, "html"));
$("#slider-options pre code").html(Prism.highlight(sliderOptions, Prism.languages.html, "html"));
$("#add-youtube-video pre code").html(Prism.highlight(addYoutubeVideo, Prism.languages.html, "html"));
$("#add-vimeo-video pre code").html(Prism.highlight(addVimeoVideo, Prism.languages.html, "html"));
$("#manage-sections pre code").html(Prism.highlight(manageSections, Prism.languages.html, "html"));
