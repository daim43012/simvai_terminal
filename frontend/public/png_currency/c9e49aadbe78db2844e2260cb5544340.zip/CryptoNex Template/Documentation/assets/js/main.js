(function ($) {
  "use strict";

  // Navbar

  $(".menu-btn").click(function (e) {
    $("#sidebar").toggleClass("active");
  });

  // Theme

  const getPreferredTheme = () => {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  };

  const setTheme = (theme) => {
    $("html").attr("data-bs-theme", theme);
  };

  setTheme(getPreferredTheme());

  $(".dark-btn").click(function (e) {
    const theme = $("html").attr("data-bs-theme");
    setTheme(theme === "dark" ? "light" : "dark");
  });
})(jQuery);
